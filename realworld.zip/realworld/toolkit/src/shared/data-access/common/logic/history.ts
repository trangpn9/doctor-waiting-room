import { NavigateFunction } from 'react-router-dom';

export const history: {
  navigate: NavigateFunction;
} = {
  navigate: {} as NavigateFunction
};
